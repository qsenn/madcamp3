const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);
const path = require('path');

app.use('/', express.static(path.join(__dirname, '')));
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {

  var id = socket.id;
  
  console.log("User ID " + id +" joined.")
  socket.on('disconnect', () => {
    console.log("User ID " + id + " disconnected");
  });
    
  socket.on('chat message', (msg) => {
    console.log('message: ' + msg);
  });

  socket.on('move', function(x,y,z){
    socket.broadcast.emit('move' , id , x ,y ,z);
    //console.log(x);
  });

  socket.on('rotate', function(x, y, z, w) {
		socket.broadcast.emit('rotate', id, x, y, z, w);
    //console.log(w);
	});

  socket.on('curHealth', function(name, curHealth) {
		socket.broadcast.emit('curHealth', name, curHealth);
    //console.log(id);
    //console.log(curHealth);
	});

  socket.on('damage', function(name, damage) {
		socket.broadcast.emit('damage', name, damage);
    console.log(name);
    console.log(id);
    console.log(damage);
	});


});

server.listen(80, () => {
  console.log('listening on *:80');
});