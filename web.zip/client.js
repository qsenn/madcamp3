var socket = io("http://192.249.18.98:80") || {};

socket.isReady = true;

window.addEventListener('load', function() {
	var execInUnity = function(method) {
		if (!socket.isReady) return;
		var args = Array.prototype.slice.call(arguments, 1);
		myGameInstance.SendMessage("Network Player Manager", method, args.join(','));
	};

    socket.on('generate', function(){
        console.log("generate");
        execInUnity("Generate");
        //myGameInstance.SendMessage("Main Camera", "Generate");
    });

    socket.on('move', function(id,x,y,z){
        execInUnity('Move', id,x,y,z);
    });

    socket.on('rotate', function(id, x, y, z ,w) {
		execInUnity('Rotate', id, x, y, z, w);
	});

    socket.on('curHealth', function(id, curHealth) {
		execInUnity('CurHealth', id , curHealth);
	});

    socket.on('damage', function(id, damage) {
		execInUnity('Damage', id , damage);
	});

    document.addEventListener( "keydown" , function () { 
        
        //myGameInstance.SendMessage( "Main Camera" , "Generate" );
        //myGameInstance.SendMessage( "Main Camera" , "test" );
        socket.emit("generate");
     } );
});

